package com.microservices.ProductmicroServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductmicroServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductmicroServicesApplication.class, args);
	}

}
